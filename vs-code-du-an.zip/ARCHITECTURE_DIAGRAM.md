# 🎨 Architecture & Data Flow Diagram

## 📐 System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER INTERFACE                            │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  Activity Logs Panel Component (ActivityLogsPanel.tsx)       │ │
│  │  ┌──────────────┬──────────────┬──────────────┐             │ │
│  │  │ Activities   │ Login Hist.  │ Statistics   │             │ │
│  │  │ Tab          │ Tab          │ Tab          │             │ │
│  │  └──────────────┴──────────────┴──────────────┘             │ │
│  └─────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
           │                      │
           ▼                      ▼
┌──────────────────────────────────────────────────────────────────┐
│                    React Hooks Layer                             │
│  ┌──────────────────────────────────────────────────────────────┤
│  │ useActivityLogs()   → Fetch & manage activity logs            │
│  │ useLoginLogs()      → Fetch & manage login logs               │
│  │ useLogStats()       → Fetch statistics                        │
│  │ useMyActivityLogs() → Fetch current user's logs               │
│  └──────────────────────────────────────────────────────────────┘
└──────────────────────────────────────────────────────────────────┘
           │                      │
           ▼                      ▼
┌──────────────────────────────────────────────────────────────────┐
│                    Service Layer                                 │
│  ┌──────────────────┬──────────────────┬──────────────────────┐ │
│  │  logService      │  loginLogService │  logHelpers          │ │
│  │  ├─ logActivity()│  ├─ logLogin()   │  ├─ logCreateAction │ │
│  │  ├─ getActivity  │  ├─ logLogout()  │  ├─ logUpdateAction │ │
│  │  ├─ getStats()   │  └─ getLoginLogs │  ├─ logDeleteAction │ │
│  │  └─ deleteOld()  │                  │  └─ createLogContext│ │
│  └──────────────────┴──────────────────┴──────────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
           │                      │
           └──────────────────────┘
                    │
                    ▼
        ┌──────────────────────┐
        │  Supabase Client     │
        │  (REST API)          │
        └──────────────────────┘
                    │
        ┌───────────┼───────────┐
        │           │           │
        ▼           ▼           ▼
    ┌────────┐ ┌─────────┐ ┌──────────┐
    │activity│ │ login   │ │ auth.    │
    │_logs   │ │ _logs   │ │ users    │
    └────────┘ └─────────┘ └──────────┘
        ▲           ▲           ▲
        └───────────┴───────────┘
        
        Supabase Database
        (PostgreSQL)
```

---

## 🔄 Activity Logging Flow

```
┌────────────────────────────────────────────────────────────────┐
│                  USER ACTION TRIGGERED                         │
│         (Login, Create Student, Update Teacher, etc)           │
└────────────────────────────────────────────────────────────────┘
                            │
                            ▼
        ┌──────────────────────────────────┐
        │ Log Action Helper Function Called │
        │ e.g., logCreateAction()           │
        │      logUpdateAction()            │
        │      logDeleteAction()            │
        └──────────────────────────────────┘
                            │
                            ▼
        ┌──────────────────────────────────┐
        │ Build Log Context                 │
        │ - userId                          │
        │ - username                        │
        │ - userRole                        │
        └──────────────────────────────────┘
                            │
                            ▼
        ┌──────────────────────────────────┐
        │ Gather Action Details             │
        │ - Action type (CREATE/UPDATE/etc) │
        │ - Resource type (student/teacher) │
        │ - Resource name                   │
        │ - IP address                      │
        │ - User agent                      │
        │ - Metadata (old/new values)       │
        └──────────────────────────────────┘
                            │
                            ▼
        ┌──────────────────────────────────┐
        │ logActivityService.logActivity()  │
        │ (Save to Supabase)                │
        └──────────────────────────────────┘
                            │
                            ▼
        ┌──────────────────────────────────┐
        │ INSERT into activity_logs table   │
        │ - timestamp                       │
        │ - user_id, username, user_role    │
        │ - action_type                     │
        │ - resource_type, resource_id      │
        │ - description, status             │
        │ - metadata (JSON)                 │
        └──────────────────────────────────┘
                            │
                            ▼
        ┌──────────────────────────────────┐
        │ Log Saved Successfully             │
        │ ✓ Visible in Activity Logs Panel   │
        └──────────────────────────────────┘
```

---

## 🔐 Login Logging Flow

```
┌────────────────────────────────────────────────────────────┐
│              USER CLICKS LOGIN                            │
└────────────────────────────────────────────────────────────┘
            │
            ▼
    ┌──────────────────┐
    │ Authenticate     │
    │ (Check creds)    │
    └──────────────────┘
            │
    ┌───────┴────────┐
    │                │
    ▼ SUCCESS        ▼ FAILED
┌─────────────┐  ┌─────────────────────┐
│ User found  │  │ Log failed login     │
└─────────────┘  │ (logActivityService) │
    │            └─────────────────────┘
    │                │
    ▼                ▼
┌─────────────────────────────────┐
│ loginLogService.logLogin()       │
│ - Get client IP                  │
│ - Get device name                │
│ - Get user agent                 │
│ - Record login_time              │
│ - Set status = 'active'          │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ INSERT into login_logs table     │
│ (Login record created)           │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ USER NAVIGATES IN APP            │
│ (Session active)                 │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ USER CLICKS LOGOUT              │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ loginLogService.logLogout()      │
│ - Calculate session duration     │
│ - Record logout_time             │
│ - Set status = 'logged_out'      │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ UPDATE login_logs table          │
│ (Login record updated)           │
└─────────────────────────────────┘
```

---

## 📊 Data Model

### activity_logs Table
```
┌─────────────────────────────────────────────────────────┐
│  activity_logs                                          │
├─────────────────────────────────────────────────────────┤
│ id                     UUID PRIMARY KEY                 │
│ user_id                UUID NOT NULL (FK users)         │
│ username               VARCHAR(255)                     │
│ user_role              VARCHAR(50) (admin/teacher/...)  │
│ action_type            VARCHAR(100) (CREATE/UPDATE/...) │
│ resource_type          VARCHAR(100) (student/teacher..)│
│ resource_id            UUID                             │
│ resource_name          VARCHAR(255)                     │
│ description            TEXT                             │
│ ip_address             VARCHAR(45)                      │
│ user_agent             TEXT                             │
│ status                 VARCHAR(20) (success/failed)     │
│ error_message          TEXT                             │
│ timestamp              TIMESTAMP (DEFAULT NOW)          │
│ duration_ms            INTEGER                          │
│ metadata               JSONB (old_values, new_values)  │
├─────────────────────────────────────────────────────────┤
│ INDEXES:                                                │
│ - idx_activity_logs_user_id                             │
│ - idx_activity_logs_timestamp DESC                      │
│ - idx_activity_logs_action_type                         │
│ - idx_activity_logs_user_id_timestamp                   │
└─────────────────────────────────────────────────────────┘
```

### login_logs Table
```
┌─────────────────────────────────────────────────────────┐
│  login_logs                                             │
├─────────────────────────────────────────────────────────┤
│ id                     UUID PRIMARY KEY                 │
│ user_id                UUID (FK users)                  │
│ username               VARCHAR(255)                     │
│ email                  VARCHAR(255)                     │
│ user_role              VARCHAR(50)                      │
│ login_time             TIMESTAMP                        │
│ logout_time            TIMESTAMP (nullable)             │
│ ip_address             VARCHAR(45)                      │
│ user_agent             TEXT                             │
│ device_name            VARCHAR(255)                     │
│ location               VARCHAR(255)                     │
│ status                 VARCHAR(20) (active/logged_out)  │
│ session_duration_secs  INTEGER (calculated)             │
├─────────────────────────────────────────────────────────┤
│ INDEXES:                                                │
│ - idx_login_logs_user_id                                │
│ - idx_login_logs_login_time DESC                        │
│ - idx_login_logs_username                               │
└─────────────────────────────────────────────────────────┘
```

---

## 🔍 Query Examples

### Get All Activities for Today
```sql
SELECT * FROM activity_logs
WHERE DATE(timestamp) = CURRENT_DATE
ORDER BY timestamp DESC;
```

### Get Activities by User
```sql
SELECT * FROM activity_logs
WHERE user_id = '123e4567-e89b-12d3-a456-426614174000'
ORDER BY timestamp DESC;
```

### Get Failed Actions
```sql
SELECT * FROM activity_logs
WHERE status = 'failed'
ORDER BY timestamp DESC;
```

### Get Active Sessions
```sql
SELECT * FROM login_logs
WHERE status = 'active'
AND logout_time IS NULL;
```

### Get Session Duration Stats
```sql
SELECT 
  username,
  COUNT(*) as total_sessions,
  AVG(session_duration_seconds) as avg_duration,
  MAX(session_duration_seconds) as max_duration
FROM login_logs
WHERE DATE(login_time) = CURRENT_DATE
GROUP BY username;
```

---

## 🎯 Permission Matrix

```
┌─────────────┬──────────────┬─────────────┬─────────────────┐
│ Role        │ View Own     │ View All    │ Manage Logs     │
│             │ Logs         │ Logs        │ (Delete Old)    │
├─────────────┼──────────────┼─────────────┼─────────────────┤
│ admin       │ ✓            │ ✓           │ ✓               │
│ teacher     │ ✓            │ ✗           │ ✗               │
│ viewer      │ ✗            │ ✗           │ ✗               │
└─────────────┴──────────────┴─────────────┴─────────────────┘
```

---

## 🏗️ Component Hierarchy

```
ActivityLogsPanel
├── Header
│   ├── Title: "Activity & Login Logs"
│   └── Description
│
├── Tabs
│   ├── Tab: Activities
│   │   ├── Filters Section
│   │   │   ├── Action Type Select
│   │   │   ├── Resource Type Select
│   │   │   ├── Start Date Input
│   │   │   ├── End Date Input
│   │   │   └── Clear Filters Button
│   │   ├── Table Section
│   │   │   ├── Loading State
│   │   │   ├── Empty State
│   │   │   └── LogRow Components
│   │   │       ├── Log Info (Collapsed)
│   │   │       └── Expanded Details
│   │   └── Pagination
│   │
│   ├── Tab: Login History
│   │   ├── Filters Section
│   │   │   ├── Date Range
│   │   │   └── Clear Filters
│   │   ├── Table Section
│   │   │   └── LoginLogRow Components
│   │   └── Pagination
│   │
│   └── Tab: Statistics
│       ├── StatCard: Total Activities
│       ├── StatCard: Total Logins Today
│       ├── StatCard: Active Users
│       └── StatCard: Failed Actions
```

---

## 🔄 State Management Flow

```
App.tsx
│
├── currentUser (AuthContext)
│   ├── id
│   ├── username
│   ├── role
│   └── permissions
│
└── ActivityLogsPanel
    │
    ├── useActivityLogs()
    │   ├── logs: ActivityLog[]
    │   ├── loading: boolean
    │   ├── error: any
    │   ├── totalCount: number
    │   ├── currentPage: number
    │   ├── filters: FilterState
    │   └── handleFilterChange()
    │
    ├── useLoginLogs()
    │   ├── logs: LoginLog[]
    │   ├── loading: boolean
    │   ├── totalCount: number
    │   └── filters: FilterState
    │
    └── useLogStats()
        ├── stats: LogStats
        ├── loading: boolean
        └── error: any
```

---

## ✨ UI/UX Flow

```
User Opens Activity Logs Panel
│
├─ Load Statistics
│  ├─ Fetch total activities
│  ├─ Fetch today's logins
│  ├─ Count active users
│  └─ Count failed actions
│
├─ Load Activities Tab
│  ├─ Display filter controls
│  ├─ Fetch initial page (page 0, 50 items)
│  ├─ Render table with logs
│  └─ Show pagination
│
├─ User Filters Activities
│  ├─ Select action type: CREATE
│  ├─ Auto-refetch (0.5s debounce)
│  ├─ Reset to page 0
│  └─ Show filtered results
│
├─ User Clicks Expand (▶)
│  ├─ Show expanded row with details
│  ├─ Display old vs new values
│  ├─ Show error message (if failed)
│  └─ Click again to collapse
│
├─ User Paginates
│  ├─ Click Next
│  ├─ Fetch page 1 (50-100)
│  └─ Render next batch
│
└─ User Switches Tab
   ├─ Load Login History
   ├─ Or Load Statistics
   └─ Maintain filter state
```

---

## 🚀 Deployment Architecture

```
┌─────────────────────────────────────────────────────────┐
│  VPS Ubuntu 22.04                                       │
│  ┌─────────────────────────────────────────────────────┐
│  │ Docker Container                                    │
│  │ ┌──────────────────────────────────────────────────┐
│  │ │ React App (Frontend)                             │
│  │ │ - ActivityLogsPanel Component                    │
│  │ │ - useActivityLogs Hook                           │
│  │ │ - logService Integration                         │
│  │ └──────────────────────────────────────────────────┘
│  └─────────────────────────────────────────────────────┘
│
├─────────────────────────────────────────────────────────┤
│  Nginx (Reverse Proxy)                                  │
│  - HTTPS/SSL                                            │
│  - Route to localhost:3000                              │
└─────────────────────────────────────────────────────────┘
```

```
         ┌─────────────────────────┐
         │   Internet              │
         │   (User's Browser)      │
         └────────────┬────────────┘
                      │
                 HTTPS/Port 443
                      │
         ┌────────────▼────────────┐
         │   VPS Nginx             │
         │   (Reverse Proxy)       │
         └────────────┬────────────┘
                      │
                HTTP/Port 3000
                      │
         ┌────────────▼────────────┐
         │  Docker Container       │
         │  React App Running      │
         └────────────┬────────────┘
                      │
              Supabase REST API
                      │
         ┌────────────▼────────────┐
         │ Supabase Cloud          │
         │ - PostgreSQL Database   │
         │ - activity_logs table   │
         │ - login_logs table      │
         └─────────────────────────┘
```

---

Diagram này menunjukkan arsitektur lengkap sistem logging dari user action hingga database! 📊
